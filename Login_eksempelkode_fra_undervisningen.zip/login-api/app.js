const restify = require('restify');
const logger = require('morgan');
const corsMiddleware = require('restify-cors-middleware');
const app = restify.createServer({
    'name': 'API Token Test',
    'version': '1.0.0'
});

const cors = corsMiddleware({
	'origins': ['*'],
	'allowHeaders': ['Authorization', 'userID']
});

app.use(restify.plugins.acceptParser(app.acceptable));
app.use(restify.plugins.bodyParser());
app.use(restify.plugins.jsonp());

app.use(logger('dev'));

app.pre(cors.preflight);
app.use(cors.actual);

require('./routes/index')(app);

app.listen(1337);